package com.example.mim.test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        TextView textView = findViewById(R.id.details_activity_Main);
        int position = getIntent().getIntExtra("Key",0);

        textView.setText(MainActivity.datalist.get(position).getmName() + "\n"+ MainActivity.datalist.get(position).getmDetails());
    }
}
