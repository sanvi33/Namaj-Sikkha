package com.example.mim.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    CustomAdapter playerAdapter;
    static List<Model> datalist = new ArrayList<Model>( );



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        listView = (ListView) findViewById( R.id.lv_activity_main_list );
        datalist.add( new Model("gdsjdf","egfefgt" ) );

        CustomAdapter adapter = new CustomAdapter(getApplicationContext(),datalist);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),Details.class);
                intent.putExtra("Key", position);
                startActivity(intent);
            }
        });

    }
}
