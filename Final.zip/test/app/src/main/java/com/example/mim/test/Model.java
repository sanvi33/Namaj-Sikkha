package com.example.mim.test;

public class Model {
    String mName;String mDetails;

    public Model(String mName, String mDetails) {
        this.mName = mName;
        this.mDetails = mDetails;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getmDetails() {
        return mDetails;
    }

    public void setmDetails(String mDetails) {
        this.mDetails = mDetails;
    }

    public Model() {



    }
}
